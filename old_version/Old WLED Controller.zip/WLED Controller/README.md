# WLED Controller with 4 Channels, line-in audio input and I2S Microphone

<h3 align="center">3D Board view</h3>
<p align="center" width="100%">
<img src="/plots/3d_front.png" alt="3D PCB"/>
<img src="/plots/3d_back.png" alt="3D PCB"/>
</p>
